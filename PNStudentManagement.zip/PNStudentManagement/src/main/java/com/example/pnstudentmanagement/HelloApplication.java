package com.example.pnstudentmanagement;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {

        DBConnection connection = new DBConnection();
        VBox root = new VBox();
        VBox studentRoot = new VBox();

        HBox hInsertStudents = new HBox();
        TextField tfName = new TextField("Nhap ten");
        TextField tfScore = new TextField("Nhap diem");
        Button btnAdd = new Button("Add");
        btnAdd.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                connection.insertStudent(new Student(tfName.getText(), Float.parseFloat(tfScore.getText())));
                getThenDisplayStudents(studentRoot, connection);
            }
        });
        hInsertStudents.getChildren().addAll(tfName, tfScore,btnAdd);

        root.getChildren().addAll(hInsertStudents, studentRoot);

        getThenDisplayStudents(studentRoot, connection);

        Scene scene = new Scene(root, 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    void displayStudents(DBConnection connection, VBox root, List<Student> students) {
        root.getChildren().clear();
        for (int i = 0; i < students.size(); i++) {
            final int finialI = i;
            HBox studentBox = new HBox();
            Label lbId = new Label("" + students.get(i).id);
            Label lbName = new Label(students.get(i).name);
            Label lbScore = new Label("" + students.get(i).scrore);
            Button btnDelete = new Button("Delete");

            btnDelete.setOnAction(actionEvent -> {
                System.out.println("Click delete " + students.get(finialI).id);

                connection.deleteStudent(students.get(finialI).id);
                getThenDisplayStudents(root, connection);
            });

            studentBox.setSpacing(20);
            studentBox.getChildren().addAll(lbId, lbName, lbScore, btnDelete);
            root.getChildren().add(studentBox);
        }
    }

    private void getThenDisplayStudents(VBox root, DBConnection connection) {
        List<Student> students = connection.getStudents();
        displayStudents(connection, root, students);
    }

    public static void main(String[] args) {
        launch();
    }
}