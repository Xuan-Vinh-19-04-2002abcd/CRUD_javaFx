package com.example.pnstudentmanagement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBConnection {

    Connection connection;

    DBConnection() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost/product", "root", "");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Connect success");
    }

    List<Student> getStudents() {
        ArrayList<Student> students = new ArrayList<>();
        try {
            ResultSet result = connection.prepareStatement("SELECT * from students").executeQuery();
            while (result.next()) {
                int id = result.getInt("id");
                String name = result.getString("name");
                float score = result.getFloat("score");
                System.out.println("=====");
                System.out.println(id);
                System.out.println(name);
                System.out.println(score);

                students.add(new Student(id, name, score));
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return students;
    }
    void insertStudent(Student student) {
        String sql = "INSERT INTO students(name,score) VALUES ('" + student.name + "'," + student.scrore + ")";
        System.out.println(sql);
        try {
            connection.prepareStatement(sql).executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    void updateStudent(Student student) {
        String sql = "UPDATE students SET name='"+student.name+"', score="+student.scrore+" WHERE id="+student.id;
        System.out.println(sql);
        try {
            connection.prepareStatement(sql).executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    void deleteStudent(int id){
        String sql = "Delete from students where id="+id;
        System.out.println(sql);
        try {
            connection.prepareStatement(sql).executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
